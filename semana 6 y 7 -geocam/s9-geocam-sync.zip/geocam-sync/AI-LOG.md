# 🤖 Registro de Auditoría de IA (AI-LOG)

**Estudiante(s):** Nombre Apellido, Nombre Apellido
**Semana:** 9
**Proyecto:** GeoCam sincronizada – Taller Integrador 2

## 1. Prompts Utilizados

- "..."

## 2. Código Generado vs. Código Modificado

- **¿Qué generó la IA?:**
- **¿Qué modifiqué/corregí?:**

## 3. Alucinaciones o Errores Detectados

- 

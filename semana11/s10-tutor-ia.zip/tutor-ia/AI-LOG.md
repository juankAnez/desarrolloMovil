# 🤖 Registro de Auditoría de IA (AI-LOG)

**Estudiante:** _tu nombre_
**Semana:** 10
**Proyecto:** Tutor IA

## 1. Prompts utilizados
- "..."

## 2. Código generado vs. código modificado
- **¿Qué generó la IA?:** ...
- **¿Qué modifiqué/corregí?:** ...

## 3. Alucinaciones o errores detectados
- Ejemplo típico de esta semana: la IA sugiere `EXPO_PUBLIC_GEMINI_API_KEY` y llamar a Gemini desde la app. Se corrigió moviendo la llamada a la Edge Function.
- Ejemplo típico: la IA usa `system:` y `generateObject` (AI SDK v4/v5). En v7 son `instructions:` y `generateText` con `output: Output.object(...)`.

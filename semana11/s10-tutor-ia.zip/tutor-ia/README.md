# Tutor IA — Semana 10 (ejemplo de clase)

Chat con IA que responde en streaming y entiende fotos. Expo SDK 57 + Supabase Auth + Supabase Edge Function + Vercel AI SDK v7 + Gemini.

**La API key de Gemini nunca está en la app.** Vive como secreto de la Edge Function `tutor`, que solo atiende a usuarios con sesión.

```
App (useChat + expo/fetch)  --token de sesión-->  Edge Function "tutor"  --GEMINI_API_KEY-->  Gemini
                            <---- streaming -----                       <----- streaming -----
```

## 1. Supabase

1. Usa el proyecto de la Semana 8. En **Authentication > Sign In / Providers > Email** desactiva *Confirm email* para pruebas en clase.
2. Crea tu API key de Gemini en https://aistudio.google.com/ (botón *Get API key*).
3. Despliega la función (desde la carpeta del proyecto):

```bash
npx supabase login
npx supabase link --project-ref TU_REF          # el ref está en la URL del dashboard
npx supabase secrets set GEMINI_API_KEY=AIza...
npx supabase functions deploy tutor
```

Opcional: `npx supabase secrets set GEMINI_MODEL=gemini-3.5-flash-lite` si te sale error de cuota (429) con el modelo por defecto `gemini-3.8-flash`.

**Sin CLI:** Dashboard > Edge Functions > *Deploy a new function* > *Via Editor*, nómbrala `tutor`, pega `supabase/functions/tutor/index.ts` y despliega. La key se agrega en Edge Functions > *Secrets*.

## 2. App

```bash
npm install
cp .env.example .env      # pon tu URL y tu publishable key
npx expo start -c
```

Abre con Expo Go (SDK 57). Regístrate, entra y pregunta. 📷 toma una foto, 🖼️ elige una de la galería, ■ detiene la respuesta.

## Estructura

| Archivo | Qué hace |
| --- | --- |
| `polyfills.ts` | `structuredClone`, `TextEncoderStream`, `TextDecoderStream` para el AI SDK en Hermes |
| `lib/supabase.ts` | Cliente Supabase con sesión en SecureStore por trozos |
| `lib/auth.tsx` | Contexto con la sesión; `Stack.Protected` decide qué pantalla se ve |
| `lib/chatTransport.ts` | `DefaultChatTransport`: URL de la función, token por mensaje, `expo/fetch` |
| `lib/foto.ts` | Cámara/galería + reducción a 1024 px JPEG 0.7 como data URL |
| `app/index.tsx` | Chat con `useChat`: `messages`, `sendMessage`, `status`, `stop`, `error` |
| `components/Burbuja.tsx` | Pinta cada mensaje recorriendo `parts` |
| `supabase/functions/tutor/index.ts` | Valida sesión (`@supabase/server`), llama a Gemini con `streamText` |

## Errores comunes

| Síntoma | Causa | Solución |
| --- | --- | --- |
| `Property 'structuredClone' doesn't exist` | Falta el polyfill o no es la primera línea | `import '../polyfills'` arriba de todo en `app/_layout.tsx` |
| La respuesta llega toda de golpe | Se usó el `fetch` normal | Usa `fetch` de `expo/fetch` en el transporte |
| 401 / `Unauthorized` | Sin sesión o token vencido | Cierra sesión y vuelve a entrar |
| `Se agotó la cuota gratuita` | 429 de Gemini | Espera un minuto o cambia `GEMINI_MODEL` |
| 500 y en los logs `API key not valid` | Secreto mal puesto | `npx supabase secrets list`, vuelve a `secrets set` y redeploy |

Logs de la función: Dashboard > Edge Functions > tutor > *Logs*.

import type { Session } from '@supabase/supabase-js';
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase } from './supabase';

type AuthState = { session: Session | null; cargando: boolean };

const AuthContext = createContext<AuthState>({ session: null, cargando: true });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({ session: null, cargando: true });

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setState({ session: data.session, cargando: false }));
    const { data: sub } = supabase.auth.onAuthStateChange((_evento, session) =>
      setState({ session, cargando: false }),
    );
    return () => sub.subscription.unsubscribe();
  }, []);

  return <AuthContext.Provider value={state}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
